在本单元中，您将创建一个Giphy App。 Giphy应用程序将搜索词作为输入，并在屏幕上的缩略图中显示随机的Gif。

为此，您将学习API请求的结构，使用AJAX发出简单的GET请求，处理JSON响应对象，并使用jQuery显示gif。

请和你的小伙伴们一起，按照以下步骤创建自己的网站！

第0步：体验

访问 https://itscodenation.github.io/adv_giphy_sol_3/ ，体验项目完成后的效果。

第一步：查询Giphy网站，显示查询结果

1）查看startcode目录下的起始代码，确保您了解这些代码。

2）修改js目录下的script.js，在点击处理程序中创建AJAX函数

3）在该函数中向Giphy的网站发送搜索请求。请求的URL是 https://api.giphy.com/v1/gifs/search?q=puppy&rating=pg&api_key=dc6zaTOxFJmzC

4）从Giphy网站返回的响应中，提取Giphy图像的URL，在屏幕上显示

第二步：获取用户输入，查询用户输入的关键字

1）当用户单击按钮时，从输入框中获取用户输入

2）根据用户输入更新Giphy的搜索URL（替代上面的URL中的”puppy）

3）发送搜索请求，并在屏幕上显示图像

第三步：完成以下扩展之一

- 创建一个“下一个”按钮，显示响应中获得的下一张图片

- 在屏幕上显示搜索到的所有图像

# 注释1

导航JSON响应

（使用下面的响应对象，完成下面的代码行，以访问原始gif图像的网址）

var pic_url = response._____________________________________

response =
{
  data:
    [
      {
        type: "gif",
        id: "FOL5mK0tXUmXe",
        slug: "puppy-burrito-dog-FOL5mK0tXUmXe",
        url: "https://giphy.com/gifs/puppy-burrito-dog-FOL5mK0tXUmXe",
        bitly_gif_url: "https://gph.is/Z0eY6e",
        bitly_url: "https://gph.is/Z0eY6e",
        embed_url: "https://giphy.com/embed/FOL5mK0tXUmXe",
        username: "",
        source: "https://littleanimalgifs.tumblr.com/post/39095638812/chichiwho-puppy-burrito",
        rating: "g",
        content_url: "",
        source_tld: "littleanimalgifs.tumblr.com",
        source_post_url: "https://littleanimalgifs.tumblr.com/post/39095638812/chichiwho-puppy-burrito",
        is_sticker: 0,
        import_datetime: "2013-03-21 03:00:50",
        trending_datetime: "1970-01-01 00:00:00",
        images:  {
            fixed_height_still: {},
            original_still: {},
            ….
            original: {
        url: "https://media2.giphy.com/media/FOL5mK0tXUmXe/giphy.gif?cid=e1bb72ff5b476c1871694f7063ab0f05",
        width: "450",
        height: "254",
        size: "949310",
        rames: "23",
        mp4: "https://media2.giphy.com/media/FOL5mK0tXUmXe/giphy.mp4?cid=e1bb72ff5b476c1871694f7063ab0f05",
        mp4_size: "83277",
        webp: "https://media2.giphy.com/media/FOL5mK0tXUmXe/giphy.webp?cid=e1bb72ff5b476c1871694f7063ab0f05",
        webp_size: "186826"
            },
            fixed_height: {},
            looping: {},
            original_mp4: {},
            preview_gif: {},
            480w_still: {}
        },
        title: "safe for work puppy GIF",
        _score: 2500048
       },
      {},
      {},
      {},
      {},
      {},
      {},
      ….
    ],
    pagination: {},
    meta: {}
}

## 项目用到的提示Popper JS库

https://www.shejidaren.com/popper-js.html