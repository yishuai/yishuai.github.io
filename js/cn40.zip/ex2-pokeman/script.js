$("#select").click(function () {
  //Your Code Goes Here
  let choice = $("#choice").val();

  fetch("https://pokeapi.co/api/v2/pokemon/" + choice)
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      console.log(data.sprites.front_female);
      $("body").append(`<img src=${data.sprites.front_default}>`);
    });
});
