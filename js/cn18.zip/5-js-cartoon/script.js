$(".talk").click(function() {
  
  
  
    
});