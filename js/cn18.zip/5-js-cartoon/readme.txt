请访问 https://popcode.org/?snapshot=a0f86b81-0cac-45dd-b77b-a86cbdf64a9e，或下载 cn18.zip，修改其中的Javascript，完成下面的功能，将用户输入的话显示在漫画人物的语音气泡上。

修改Javascript，在点击（click）处理程序内，

1. 利用val函数，将用户输入的值（选择其类“speech”）保存到名为“ message”的新变量中。

2. 利用text函数，用该变量设置语音气泡（类为“speech-bubble”）的内容，使用户的话，在语音气泡中出现。

请提交你网页的URL