

// 1. 英语

$(".englishButton").click(function(){
    let englishInput = $(".english").val();
        
    //如果答案正确，则显示此文本
    
    $(".englishMessage").text("正确!");
    
    //如果答案不正确，则显示此文本
    
    $(".englishMessage").text("错误！请再试一次"); 
    
});


// 2. 地理

$(".ssButton").click(function(){
    let ssInput = $(".socialStudies").val();

    
});


// 3. 数学

$(".mathButton").click(function(){
    let mathInput = $(".math").val();
    
    //下面，我们使用parseInt（）函数将输入值（字符串）转换为数字
    
    mathInput = parseInt(mathInput);


});


// 4. 科学



