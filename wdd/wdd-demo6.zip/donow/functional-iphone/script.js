/**
 * Some functionality still in progress
 */

$(document).ready(function() {
  var pressed = 0;
  $('.home-button').on('click', function() {
    pressed += 1;
    $('.off').addClass('hide');
    if (pressed == 1) {
      $('.locked').removeClass('hide');
    } else {
      $('.locked').addClass('hide');
      $('.secretive').addClass('hide');
      $('.unlocked').removeClass('hide');
    }
  });
  
  $('.side-button').on('click', function() {
    $('.unlocked').addClass('hide');
    $('.locked').addClass('hide');
    $('.secretive').addClass('hide');
    $('.off').removeClass('hide');
    pressed = 0;
  });
  
  $('.secret').on('click', function() {
    $('.unlocked').addClass('hide');
    $('.locked').addClass('hide');
    $('.off').addClass('hide');
    $('.secretive').removeClass('hide');
  })
});