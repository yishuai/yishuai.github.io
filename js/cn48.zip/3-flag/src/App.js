import React, { Component } from 'react';
import Flag from "./components/Flag/Flag.js";
import './App.css';

class App extends Component {
  render() {
    return (
    <div>
    <Flag />
    </div>
    );
  }
}

export default App;
