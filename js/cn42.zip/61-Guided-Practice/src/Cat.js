import React from "react";
import "./App.css";

export default function Cat() {
  return (
    <div className="Cat">
      <img src="kitten-tabby.jpg" />
      <p> 猫咪：我可爱吗？</p>
    </div>
  );
}
