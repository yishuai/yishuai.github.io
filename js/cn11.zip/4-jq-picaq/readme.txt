请访问 https://popcode.org/?snapshot=cc72b480-da29-411d-bbf5-1889b9fe04d6，或下载 cn11.zip，完成下面的游戏

＃06.2 jQuery Actions欢乐屋

修改Javascript，使用 jQuery Actions 给此页面添加交互性。

1）单击车库开启器（garage-door-opener）时，车库门（garage-door）上下滑动（slideup，slidedown）。 别忘记为首次单击处理程序填写适当的选择器。

2）单击Pokeball时，皮卡丘（Pikachu）淡入（fadein）。

3）单击灯开关（light-switch）时，灯泡（light-bulb）显示（show）和隐藏（hide）。

附加功能：

1）向单击（click）处理程序（function）添加第二个jQuery动作，这样就会在单击时，发生多个动作。

2）添加一个你自己的开关和图像

请提交你网页的URL