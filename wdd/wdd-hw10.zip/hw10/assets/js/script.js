$(document).ready(function() {


  // a js 对象，存储音频ID
  let sounds = {
      81 : 'kick-sound', //键 q
      87 : 'snare-sound', //键 w
      69 : 'hat-sound', //键 e
      82 : 'glass-sound' //键 r
    }

  //原理。当键被按下后，
  //我们获取与该键对应的声音，
  //将其存储到soundId变量。
  //如果soundId存在，则转到该声音的开头，然后播放。
  //这对较长的音频文件或快速按键非常重要，
  //这样我们才能快速播音
  //如果soundId不存在，我们将播放牛铃音。

  document.onkeydown = function(e) {
      let soundId = sounds[e.keyCode];
      if (soundId) {
        sound = document.getElementById(soundId);
      }
      else {
        sound = document.getElementById("cowbell-sound");
      }
      sound.currentTime = 0;
      sound.play();
    }


    $('body').on('keydown', function(e){
      // **************************************
      // 请勿更改此行上的任何内容
      // **************************************



      // 为每个键添加5条条件语句，
      // 其中4个应该是 sounds js 对象中列出的键的代码
      // 而最后一条语句应处理任何其他键
      // 对于每个条件，应显示正确的叠加层并淡出
      // 除了第五个条件
      // 提示：请使用 e.which
      // **************************
      // 在下面创建条件
      // **************************






  });


  //一个用于存储流行歌手姓名的js对象。
  //你可以更改艺术家或添加一些艺术家！确保你的
  //for循环中的索引对应于这里的艺术家数量
    let artists = {
      0 : 'Bruno Mars',
      1 : 'Chance',
      2 : 'Cardi B',
      3 : 'JJ Swagger',
      4 : 'Queen',
      5 : 'Miles Davis',
      6 : 'Taylor Swift',
      7 : 'Vulfpeck',
    }

  // HINT - Think about what the bounds of the for loop should be
  // HINT - $("body").append("<div class='red'></div>"); would add a
  // new div with the class of 'red' to the body. Note how we are passing
  // in a string to .append()
  // HINT - You will be using string concatination; i.e. "race" + "car" returns "racecar"
  // HINT - We can get "apple" in let fruits = {4:"apple"} through fruits[4]
  // ************************************
  // Create your for loop below this line
  // ************************************

  // 提示 - 注意for循环的范围
  // 提示 - 可以用 $("body").append("<div class='red'></div>"); 添加
  // “红色”类的新div。
  // 提示 - let fruit = {4：“ apple”} 后，通过 fruit[4]，我们可以获得“apple”
  //****************************************
  // 在此行下创建for循环
  //****************************************



});
