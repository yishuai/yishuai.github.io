$(".whack1").click(function(){
    $(".mole1").hide();
});
    
$("改这").click(function(){
    $("改这").hide();
});
    
$("改这").click(function(){
    $("改这").hide();
});
    
$("改这").click(function(){
    $("改这").show();
});