import React, { Component } from "react";
import FlagColor from "../FlagColor/FlagColor.js";
import "./Flag.css";

export default class Flag extends Component {
  render() {
    return (
      <div className="flag horizontal">
        <FlagColor 颜色="red" />
      </div>
    );
  }
}
