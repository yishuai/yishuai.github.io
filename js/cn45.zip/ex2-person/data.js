const data = [
  {
    "name": "Ameil Stanek",
    "age": 38,
    "phone": "483-993-0923"
  },

  {
    "name1": "Carla",
    "name2": "Lalli",
    "name3": "Music",
    "age": 45,
    "phone": "945-552-6111"
  },

  {
    "name": "Christina Chaey",
    "age": "29",
    "phone": "455-652-3145"
  },
  {
    "name": "Molly Baz",
    "age": 35
  },
  {
    "name": "Brad Leone",
    "age": 46,
    "phone": "1158439542"
  },
  {
    "name": "Claire Saffitz",
    "age": 30,
    "phone": "465-985-0012"
  },
    {
    "name": "Allison Roman",
    "age": 32,
    "phone": "457-994-5462",
    "books": ["Dining In", "Nothing Fancy"]
  },
  {
    "name": "Alex Beggs",
    "age": 21,
    "phone": "785-424-6351"
  },
    {
    "name": "Priya",
    "lastName": "Krishna",
    "age": 25,
    "phone": "801-421-6121"
  },
  {
    "name": "chris morocco      ",
    "age": 36,
    "phone": "121-885-9645"
  },
  {
    "name": "Andy Baraghani",
    "age": 28,
    "phone": "753-951-4652"
  },
  {
    "name": "Samin Nosrat",
    "birthYear": 1981,
    "phone": "121-889-6523"
  },
  {
    "name": "Alex Delaney",
    "age": 33,
    "phone": "454-442-9888"
  },
  {
    "name": "Rick Martinez",
    "age": 54,
    "phone": "454-985-1554"
  },
  {
    "name": "Alex Lau",
    "age": 29,
    "phone": "7844456112",
    "occupation": "photographer"
  },
  {
    "name": "Adam Rappoport",
    "age": 50,
    "phone": "453-888-8898"
  },
  {
    "name": "Sohla El-Waylly",
    "age": 12,
    "areaCode": "751",
    "phone": "923-9045"
  },
  {
    "name": "Sarah Jampel",
    "age": 19,
    "phone": "644-788-9452"
  },
  {
    "name": "gabby Melian",
    "age": "54",
    "phone": "112-778-9999545-88886"
  }
];

export { data };