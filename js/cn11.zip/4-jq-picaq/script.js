$("      ").click(function() {
    
});

$("       ").click(function() {
    
});

$("        ").click(function() {

});