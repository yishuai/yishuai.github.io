function hi() {
  return "你好，我在 2.js 文件里!";
}
