import React from "react";
import "./App.css";

export default function Item(props) {
  return (
    <div className="Item">
      <img src={props.url} />
      <ul>
        <li>{props.name}</li>
        <li>${props.price}</li>
      </ul>
    </div>
  );
}
