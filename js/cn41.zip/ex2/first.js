$("#hi").click(function () {
  const val = a.hi();
  $("#area").append(val + "<br>");
});

$("#bye").click(function () {
  const val = a.bye();
  $("#area").append(val + "<br>");
});
