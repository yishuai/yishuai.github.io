你的专属美图秀秀

请访问 https://popcode.org/?snapshot=00ca7fc4-4ca4-4043-933b-30df1b2da974，或下载 cn21.zip，修改里面的Javascript代码，完成下面的美图秀秀网站。

1）按照JavaScript代码中的注释说明，使用if，else-if和else条件语句，检查用户输入的滤镜名称，给图片加上不同的滤镜。

关于CSS滤镜的使用方法，请参考菜鸟教程：https://www.runoob.com/cssref/css3-pr-filter.html 和 MDN教程：
https://developer.mozilla.org/zh-CN/docs/Web/CSS/filter

加分项：

1）参考CSS滤镜的介绍，创建一个以您自己的名字命名的新的滤镜！

2）创建另一个输入框，用户可以在其中输入数字，更改图像的大小。

请提交你网页的URL