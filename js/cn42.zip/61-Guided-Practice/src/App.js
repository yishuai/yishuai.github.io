import React from "react";
import Cat from "./Cat.js";
import "./App.css";

export default function App() {
  return (
    <div>
      <h1> 猫之国 </h1>
      <Cat />
      <Cat />
      <Cat />
      <Cat />
      <Cat />
      <Cat />
    </div>
  );
}
