自动改卷

请访问 https://popcode.org/?snapshot=ea3c0695-b65d-42d4-8ee7-ae8fefbbae05，或下载 cn20.zip，修改其中的Javascript，完成下面的功能：

对每个问题， 编写一个if/else条件语句，检查学生的回答是否正确，并且用.text（）在输入框下面的div中显示结果正确或错误。

加分项：

当学生答案正确时，请将显示的结果背景设为绿色。如果错误，请设成红色。

请提交你网页的URL