import React, { Component } from "react";
import "./Question.css";

class Question extends Component {
  render() {
    return <div className="questionElem">{this.props.questionText}</div>;
  }
}

export default Question;
