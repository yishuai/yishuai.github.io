let movieReviewPikachu;

$(".pokemon").click(function () {
  $(".movieReviews").text("");
});

$(".calculateTotal").click(function () {
  let child;
  let adult;
  let totalCost;
  if (totalCost) {
  }
});
