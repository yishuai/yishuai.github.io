$("button").click(function () {
  let request_url = "https://api.tvmaze.com/search/shows?q=superman";

  fetch(request_url)
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      let pic_url = data[2].show.image.medium;
      $("body").append(`<img src='${pic_url}'>`);
    });
});
