function hi() {
  return "你好（来自 second.js)!";
}

function bye() {
  return "再见（来自 second.js)!";
}
