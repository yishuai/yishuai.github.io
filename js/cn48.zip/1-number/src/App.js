import React, { Component } from "react";
import "./App.css";
import Number from "./Number";

class App extends Component {
  render() {
    return (
      <div className="App">
        <h3>这是我最喜欢的电话号码：</h3>
        <Number 号码="88888888" />
      </div>
    );
  }
}

export default App;
