
//
// Part 1: 修改 setBackgroundColor() 所以 #q1-container 的背景色更改为指定的颜色
//

/**
 * 设置 #q1-container 的背景色
 *
 * @param {string} color #q1-container 应该被设为的背景色
 */
function setBackgroundColor(color) {
    // TODO: 获取ID为“q1-container”的元素，并将其背景色设置为输入色





}

//
// Part 2: 编写函数redButtonClicked（）的代码，并在单击＃q1-btn-red时使浏览器为您运行该函数
//

// 对于红色按钮，使用颜色＃EF476F，或者根据自己的喜好更改颜色
// 如果您决定更改颜色，请也考虑更新CSS中的相应按钮颜色 :)

/**
 * 单击红色按钮时浏览器应运行的处理程序
 */
function redButtonClicked() {
    // TODO: 使用setBackgroundColor（）将背景色设置为＃EF476F（或您选择的另一种颜色）





}

// 这将获取ID为“ q1-btn-red”的元素，并设置浏览器，在有人单击该元素时运行redButtonClicked（）函数
document.getElementById("q1-btn-red").onclick = redButtonClicked;

// 完成第1部分和第2部分后，单击红色按钮应将背景色变为红色！

//
// Part 3: 对黄色按钮进行编程，类似于对红色按钮所做的操作
//

// 对于黄色按钮
// 使用颜色＃FFD166，或根据自己的喜好更改颜色

// TODO: 定义诸如yellowButtonClicked（）之类的函数来设置背景色





// TODO: 设置浏览器以在有人单击＃q1-btn-yellow时运行功能yellowButtonClicked（）





//
// Part 4: 更多练习，让我们对其余按钮做同样的事情
//

// 对于绿色按钮
// Use the color #06D6A0, or change it up to your liking

// TODO: Make the green button work similarly





// 对于浅蓝色按钮
// Use the color #118AB2, or change it up to your liking

// TODO: Make the light blue button work similarly





// 对于蓝色按钮
// Use the color #073B4C, or change it up to your liking

// TODO: Make the blue button work similarly
