var levels = [
  {
    helpTitle: "按类型选择元素",
    selectorName: "类型选择器",
    doThis: "选择盘子",
    selector: "plate",
    syntax: "A",
    help:
      "选择<strong> A </strong>类型的所有元素。类型是指标签的类型，因此<tag> div </tag>，<tag> p </tag>和<tag> ul </tag>都是不同的元素类型。",
    examples: [
      "<strong> div </strong>选择所有<tag> div </tag>元素。",
      "<strong>p</strong> selects all <tag>p</tag> elements.",
    ],
    boardMarkup: `
    <plate/>
    <plate/>
    `,
  },
  {
    doThis: "选择便当盒",
    selector: "bento",
    syntax: "A",
    helpTitle: "按类型选择元素",
    selectorName: "类型选择器",
    help:
      "选择<strong> A </strong>类型的所有元素。类型是指标签的类型，因此<tag> div </tag>，<tag> p </tag>和<tag> ul </tag>都是不同的元素类型。",
    examples: [
      "<strong>div</strong> selects all <tag>div</tag> elements.",
      "<strong>p</strong> selects all <tag>p</tag> elements.",
    ],
    boardMarkup: `
    <bento/>
    <plate/>
    <bento/>
    `,
  },
  {
    doThis: "选择花式盘子",
    selector: "#fancy",
    selectorName: "ID选择器",
    helpTitle: "选择具有ID的元素",
    syntax: "#id",
    help:
      "选择具有特定<strong> id </strong>的元素。您也可以将ID选择器与类型选择器结合使用。",
    examples: [
      '<strong>#cool</strong> selects any element with <strong>id="cool"</strong>',
      '<strong>ul#long</strong> selects <tag>ul id="long"</tag>',
    ],
    boardMarkup: `
    <plate id="fancy"/>
    <plate/>
    <bento/>
    `,
  },
  {
    helpTitle: "选择另一个元素内的一个元素",
    selectorName: "后代选择器",
    doThis: "选择盘子上的苹果",
    selector: "plate apple",
    syntax: "A&nbsp;&nbsp;B",
    help:
      "选择<strong> A </strong>中的所有<strong> B </strong>。 <strong> B </strong>之所以称为后代，是因为它在另一个元素内。",
    examples: [
      "<strong>p&nbsp;&nbsp;strong</strong> selects all <tag>strong</tag> elements that are inside of any <tag>p</tag>",
      '<strong>#fancy&nbsp;&nbsp;span</strong> selects any <tag>span</tag> elements that are inside of the element with <strong>id="fancy"</strong>',
    ],
    boardMarkup: `
    <bento/>
    <plate>
      <apple/>
    </plate>
    <apple/>
    `,
  },
  {
    doThis: "选择花式盘子上的泡菜",
    selector: "#fancy pickle",
    helpTitle: "结合后代和ID选择器",
    syntax: "#id&nbsp;&nbsp;A",
    help: "You can combine any selector with the descendent selector.",
    examples: [
      '<strong>#cool&nbsp;span</strong> selects all <tag>span</tag> elements that are inside of elements with <strong>id="cool"</strong>',
    ],
    boardMarkup: `
    <bento>
    <orange/>
    </bento>
    <plate id="fancy">
      <pickle/>
    </plate>
    <plate>
      <pickle/>
    </plate>
    `,
  },
  {
    doThis: "选择小苹果",
    selector: ".small",
    selectorName: "类选择器",
    helpTitle: "按类别选择元素",
    syntax: ".classname",
    help:
      "类选择器选择具有该类属性的所有元素。元素只能有一个ID，但可以有多个类。",
    examples: [
      '<strong>.neato</strong> selects all elements with <strong>class="neato"</strong>',
    ],
    boardMarkup: `
    <apple/>
    <apple class="small"/>
    <plate>
      <apple class="small"/>
    </plate>
    <plate/>
    `,
  },
  {
    doThis: "选择小橘子",
    selector: "orange.small",
    helpTitle: "结合类选择器",
    syntax: "A.className",
    help: "您可以将类选择器与其他选择器（例如类型选择器）组合在一起。",
    examples: [
      '<strong>ul.important</strong> selects all <tag>ul</tag> elements that have <strong>class="important"</strong>',
      '<strong>#big.wide</strong> selects all elements with <strong>id="big"</strong> that also have <strong>class="wide"</strong>',
    ],
    boardMarkup: `
    <apple/>
    <apple class="small"/>
    <bento>
      <orange class="small"/>
    </bento>
    <plate>
      <orange/>
    </plate>
    <plate>
      <orange class="small"/>
    </plate>`,
  },
  {
    doThis: "选择便当中的小橘子",
    selector: "bento orange.small",
    syntax: "Put your back into it!",
    helpTitle: "你能行的...",
    help: "Combine what you learned in the last few levels to solve this one!",
    boardMarkup: `
    <bento>
      <orange/>
    </bento>
    <orange class="small"/>
    <bento>
      <orange class="small"/>
    </bento>
    <bento>
      <apple class="small"/>
    </bento>
    <bento>
      <orange class="small"/>
    </bento>
    `,
  },
  {
    doThis: "选择所有的盘子和便当",
    selector: "plate,bento",
    selectorName: "逗号组合器",
    helpTitle: "结合选择器和...逗号！",
    syntax: "A, B",
    help:
      "由于使用了Shatner技术，因此可以选择所有<strong> A </strong>和<strong> B </strong>元素。您可以通过这种方式组合任何选择器，并且可以指定两个以上。",
    examples: [
      '<strong>p, .fun</strong> selects all <tag>p</tag> elements as well as all elements with <strong>class="fun"</strong>',
      "<strong>a, p, div</strong> selects all <tag>a</tag>, <tag>p</tag> and <tag>div</tag> elements",
    ],
    boardMarkup: `
    <pickle class="small"/>
    <pickle/>
    <plate>
      <pickle/>
    </plate>
    <bento>
      <pickle/>
    </bento>
    <plate>
      <pickle/>
    </plate>
    <pickle/>
    <pickle class="small"/>
    `,
  },
  {
    doThis: "选择所有东西！",
    selector: "*",
    selectorName: "通用选择器",
    helpTitle: "您可以选择所有内容！",
    syntax: "*",
    help: "You can select all elements with the universal selector! ",
    examples: [
      "<strong>p *</strong> selects any element inside all <tag>p</tag> elements.",
    ],
    boardMarkup: `
    <apple/>
    <plate>
      <orange class="small" />
    </plate>
    <bento/>
    <bento>
      <orange/>
    </bento>
    <plate id="fancy"/>
    `,
  },
  {
    doThis: "选择盘子上的所有东西",
    selector: "plate *",
    syntax: "A&nbsp;&nbsp;*",
    helpTitle: "结合通用选择器",
    help: "This selects all elements inside of <strong>A</strong>.",
    examples: [
      "<strong>p *</strong> selects every element inside all <tag>p</tag> elements.",
      '<strong>ul.fancy *</strong> selects every element inside all <tag>ul class="fancy"</tag> elements.',
    ],
    boardMarkup: `
    <plate id="fancy">
      <orange class="small"/>
    </plate>
    <plate>
      <pickle/>
    </plate>
    <apple class="small"/>
    <plate>
      <apple/>
    </plate>`,
  },
  {
    doThis: "选择盘子旁边的每个苹果",
    selector: "plate + apple",
    helpTitle: "Select an element that directly follows another element",
    selectorName: "相邻兄弟选择器",
    syntax: "A + B",
    help:
      "这将选择紧随<strong> A </strong>的所有<strong> B </strong>元素。彼此相邻的元素称为同级。它们处于相同的水平或深度。 <br/> <br/>在此级别的HTML标记中，具有相同缩进的元素是同级。",
    examples: [
      '<strong>p + .intro</strong> selects every element with <strong>class="intro"</strong> that directly follows a <tag>p</tag>',
      "<strong>div + a</strong> selects every <tag>a</tag> element that directly follows a <tag>div</tag>",
    ],
    boardMarkup: `
    <bento>
      <apple class="small"/>
    </bento>
    <plate />
    <apple class="small"/>
    <plate />
    <apple/>
    <apple class="small"/>
    <apple class="small"/>
    `,
  },
  {
    selectorName: "通用兄弟选择器",
    helpTitle: "Select elements that follows another element",
    syntax: "A ~ B",
    doThis: "选择便当旁边的泡菜",
    selector: "bento ~ pickle",
    help:
      "您可以选择元素之后的所有同级元素。就像相邻选择器（A + B）一样，只是它获取以下所有元素而不是一个。",
    examples: [
      "<strong>A ~ B</strong> selects all <strong>B</strong> that follow a <strong>A</strong>",
    ],
    boardMarkup: `
    <pickle/>
    <bento>
      <orange class="small"/>
    </bento>
    <pickle class="small"/>
    <pickle/>
    <plate>
      <pickle/>
    </plate>
    <plate>
      <pickle class="small"/>
    </plate>
    `,
  },
  {
    selectorName: "儿童选择器",
    syntax: "A > B&nbsp;",
    doThis: "直接在盘子上选择苹果",
    selector: "plate > apple",
    helpTitle: "选择元素的直接子代",
    help:
      "您可以选择作为其他元素的直接子元素的元素。子元素是直接嵌套在另一个元素中的任何元素。 <br> <br>嵌套得比嵌套更深的元素称为后代元素。",
    examples: [
      "<strong>A > B</strong> selects all <strong>B</strong> that are a direct children <strong>A</strong>",
    ],
    boardMarkup: `
    <plate>
      <bento>
        <apple/>
      </bento>
    </plate>
    <plate>
      <apple/>
    </plate>
    <plate/>
    <apple/>
    <apple class="small"/>
    `,
  },
  {
    selectorName: "第一个孩子伪选择器",
    helpTitle: "Select a first child element inside of another element",
    doThis: "选择顶部的橙色",
    selector: "plate :first-child",
    syntax: ":first-child",

    help:
      "您可以选择第一个子元素。子元素是直接嵌套在另一个元素中的任何元素。您可以将此伪选择器与其他选择器结合使用。",
    examples: [
      "<strong>:first-child</strong> selects all first child elements.",
      "<strong>p:first-child</strong> selects all first child <tag>p</tag> elements.",
      "<strong>div p:first-child</strong> selects all first child <tag>p</tag> elements that are in a <tag>div</tag>.",
    ],
    boardMarkup: `
    <bento/>
    <plate />
    <plate>
      <orange />
      <orange />
      <orange />
    </plate>
    <pickle class="small" />
    `,
  },
  {
    selectorName: "独生子伪选择器",
    helpTitle:
      "Select an element that are the only element inside of another one.",
    doThis: "Select the apple and the pickle on the plates",
    selector: "plate :only-child",
    syntax: ":only-child",
    help: "您可以选择任何元素作为另一个元素中的唯一元素。",
    examples: [
      "<strong>span:only-child</strong> selects the <tag>span</tag> elements that are the only child of some other element.",
      "<strong>ul li:only-child</strong> selects the only <tag>li</tag> element that are in a <tag>ul</tag>.",
    ],
    boardMarkup: `
    <plate>
      <apple/>
    </plate>
    <plate>
      <pickle />
    </plate>
    <bento>
      <pickle />
    </bento>
    <plate>
      <orange class="small"/>
      <orange/>
    </plate>
    <pickle class="small"/>
    `,
  },
  {
    selectorName: "最后一个孩子伪选择器",
    helpTitle: "Select the last element inside of another element",
    doThis: "选择小苹果和泡菜",
    selector: ".small:last-child",
    syntax: ":last-child",
    help:
      "您可以使用此选择器选择一个元素，该元素是另一个元素内的最后一个子元素。 <br> <br>专业提示→在只有一个元素的情况下，该元素将计为第一个孩子，唯一孩子和最后一个孩子！",
    examples: [
      "<strong>:last-child</strong> selects all last-child elements.",
      "<strong>span:last-child</strong> selects all last-child <tag>span</tag> elements.",
      "<strong>ul li:last-child</strong> selects the last <tag>li</tag> elements inside of any <tag>ul</tag>.",
    ],
    boardMarkup: `
    <plate id="fancy">
      <apple class="small"/>
    </plate>
    <plate/>
    <plate>
      <orange class="small"/>
      <orange>
    </plate>
    <pickle class="small"/>`,
  },
  {
    selectorName: "第N个孩子伪选择器",
    helpTitle: "Select an element by its order in another element",
    doThis: "选择第三个盘子",
    selector: ":nth-child(3)",
    syntax: ":nth-child(A)",
    help:
      "在另一个元素中选择<strong> nth </strong>（例如：1、3、12等）子元素。",
    examples: [
      "<strong>:nth-child(8)</strong> selects every element that is the 8th child of another element.",
      "<strong>div p:nth-child(2)</strong> selects the second <strong>p</strong> in every <strong>div</strong>",
    ],
    boardMarkup: `
    <plate/>
    <plate/>
    <plate/>
    <plate id="fancy"/>
    `,
  },
  {
    selectorName: "最后一个孩子选择器",
    helpTitle:
      "Select an element by its order in another element, counting from the back",
    doThis: "选择第一便当",
    selector: "bento:nth-last-child(3)",
    syntax: ":nth-last-child(A)",
    help: "从父级的底部选择子级。这就像第n个孩子，但从后面数！",
    examples: [
      "<strong>:nth-last-child(2)</strong> selects all second-to-last child elements.",
    ],
    boardMarkup: `
    <plate/>
    <bento/>
    <plate>
      <orange/>
      <orange/>
      <orange/>
    </plate>
    <bento/>
    `,
  },
  {
    selectorName: "第一类选择器",
    helpTitle: "Select the first element of a specific type",
    doThis: "选择第一个苹果",
    selector: "apple:first-of-type",
    syntax: ":first-of-type",
    help: "Selects the first element of that type within another element.",
    examples: [
      "<strong>span:first-of-type</strong> selects the first <tag>span</tag> in any element.",
    ],
    boardMarkup: `
    <orange class="small"/>
    <apple/>
    <apple class="small"/>
    <apple/>
    <apple class="small"/>
    <plate>
      <orange class="small"/>
      <orange/>
    </plate>
    `,
  },
  {
    selectorName: "类型选择器的第N个",
    doThis: "Select all even plates",
    selector: "plate:nth-of-type(even)",
    syntax: ":nth-of-type(A)",
    help:
      "根据其类型和在另一个元素中的顺序选择特定元素-或该元素的偶数或奇数实例。",
    examples: [
      "<strong>div:nth-of-type(2)</strong> selects the second instance of a div.",
      "<strong>.example:nth-of-type(odd)</strong> selects all odd instances of a the example class.",
    ],
    boardMarkup: `
    <plate/>
    <plate/>
    <plate/>
    <plate/>
    <plate id="fancy"/>
    <plate/>
    `,
  },
  {
    selectorName: "具有公式的第N个选择器",
    doThis: "Select every 2nd plate, starting from the 3rd",
    selector: "plate:nth-of-type(2n+3)",
    syntax: ":nth-of-type(An+B)",
    help: "第n个类型的公式会选择每个第n个元素，并从该元素的特定实例开始计数。",
    examples: [
      "<strong>span:nth-of-type(6n+2)</strong> selects every 6th instance of a <tag>span</tag>, starting from (and including) the second instance.",
    ],
    boardMarkup: `
    <plate/>
    <plate>
      <pickle class="small" />
    </plate>
    <plate>
      <apple class="small" />
    </plate>
    <plate/>
    <plate>
      <apple />
    </plate>
    <plate/>
    `,
  },
  {
    selectorName: "仅类型选择器",
    helpTitle:
      "Select elements that are the only ones of their type within of their parent element",
    selector: "apple:only-of-type",
    syntax: ":only-of-type",
    doThis: "选择中间盘子上的苹果",
    help: "Selects the only element of its type within another element.",
    examples: [
      "<strong>p span:only-of-type</strong> selects a <tag>span</tag> within any <tag>p</tag> if it is the only <tag>span</tag> in there.",
    ],
    boardMarkup: `
    <plate id="fancy">
      <apple class="small" />
      <apple />
    </plate>
    <plate>
      <apple class="small" />
    </plate>
    <plate>
      <pickle />
    </plate>
    `,
  },
  {
    selectorName: "最后一个类型选择器",
    helpTitle: "Select the last element of a specific type",
    doThis: "选择最后一个苹果和橘子",
    selector: ".small:last-of-type",
    syntax: ":last-of-type",
    help:
      "在另一个元素中选择该类型的每个最后一个元素。请记住，类型是指标记的类型，因此<tag> p </tag>和<tag> span </tag>是不同的类型。 <br> <br>我想知道这是否是最后一只恐龙灭绝前的选择方式。",
    examples: [
      "<strong>div:last-of-type</strong> selects the last <tag>div</tag> in every element.",
      "<strong>p span:last-of-type</strong> selects the last <tag>span</tag> in every <tag>p</tag>.",
    ],
    boardMarkup: `
    <orange class="small"/>
    <orange class="small" />
    <pickle />
    <pickle />
    <apple class="small" />
    <apple class="small" />
    `,
  },
  {
    selectorName: "空选择器",
    helpTitle: "选择没有子元素",
    doThis: "选择空便当",
    selector: "bento:empty",
    syntax: ":empty",
    help: "Selects elements that don't have any other elements inside of them.",
    examples: [
      "<strong>div:empty</strong> selects all empty <tag>div</tag> elements.",
    ],
    boardMarkup: `
    <bento/>
    <bento>
      <pickle class="small"/>
    </bento>
    <plate/>
    <bento/>`,
  },
  {
    selectorName: "否定伪类",
    helpTitle: "Select all elements that don't match the negation selector",
    doThis: "选择大苹果",
    selector: "apple:not(.small)",
    syntax: ":not(X)",
    help:
      'You can use this to select all elements that do not match selector <strong>"X"</strong>.',
    examples: [
      '<strong>:not(#fancy)</strong> selects all elements that do not have <strong>id="fancy"</strong>.',
      "<strong>div:not(:first-child)</strong> selects every <tag>div</tag> that is not a first child.",
      '<strong>:not(.big, .medium)</strong> selects all elements that do not have <strong>class="big"</strong> or <strong>class="medium"</strong>.',
    ],
    boardMarkup: `
    <plate id="fancy">
      <apple class="small" />
    </plate>
    <plate>
      <apple />
    </plate>
    <apple />
    <plate>
      <orange class="small" />
    </plate>
    <pickle class="small" />
    `,
  },
  {
    selectorName: "属性选择器",
    helpTitle: "Select all elements that have a specific attribute",
    doThis: "选择某人的物品",
    selector: "[for]",
    syntax: "[attribute]",
    help:
      'Attributes appear inside the opening tag of an element, like this: <tag>span attribute="value"</tag>. An attribute does not always have a value, it can be blank!',
    examples: [
      '<strong>a[href]</strong> selects all <tag>a</tag> elements that have a <strong>href="anything"</strong> attribute.',
      '<strong>[type]</strong> selects all elements that have a <strong>type="anything"</strong>. attribute',
    ],
    boardMarkup: `
    <bento><apple class="small"/></bento>
    <apple for="Ethan"/>
    <plate for="Alice"><pickle/></plate>
    <bento for="Clara"><orange/></bento>
    <pickle/>`,
  },
  {
    selectorName: "属性选择器",
    helpTitle: "Select all elements that have a specific attribute",
    doThis: "选择某人的盘子",
    selector: "plate[for]",
    syntax: "A[attribute]",
    help:
      "通过将属性选择器添加到末尾，将其与另一个选择器（例如标签名称选择器）组合起来。",
    examples: [
      '<strong>[value]</strong> selects all elements that have a <strong>value="anything"</strong> attribute.',
      '<strong>a[href]</strong> selects all <tag>a</tag> elements that have a <strong>href="anything"</strong> attribute.',
      "<strong>input[disabled]</strong> selects all <tag>input</tag> elements with the <strong>disabled</strong> attribute",
    ],
    boardMarkup: `
    <plate for="Sarah"><pickle/></plate>
    <plate for="Luke"><apple/></plate>
    <plate/>
    <bento for="Steve"><orange/></bento>
    `,
  },
  {
    selectorName: "属性值选择器",
    helpTitle: "Select all elements that have a specific attribute value",
    doThis: "选择维塔利餐",
    selector: "[for=Vitaly]",
    syntax: '[attribute="value"]',
    help: "属性选择器区分大小写，每个字符必须完全匹配。",
    examples: [
      '<strong>input[type="checkbox"]</strong> selects all checkbox input elements.',
    ],
    boardMarkup: `
    <apple for="Alexei" />
    <bento for="Albina"><apple /></bento>
    <bento for="Vitaly"><orange/></bento>
    <pickle/>
    `,
  },
  {
    selectorName: "属性从选择器开始",
    helpTitle:
      "Select all elements with an attribute value that starts with specific characters",
    doThis: "Select the items for names that start with 'Sa'",
    selector: '[for^="Sa"]',
    syntax: '[attribute^="value"]',
    // help : "You can use quotes around the value in the selector, or not&mdash;it's optional!",
    examples: [
      '<strong>.toy[category^="Swim"]</strong> selects elements with class <strong>toy</strong> and either <strong>category="Swimwear</strong> or <strong>category="Swimming"</strong>.',
    ],
    boardMarkup: `
    <plate for="Sam"><pickle/></plate>
    <bento for="Sarah"><apple class="small"/></bento>
    <bento for="Mary"><orange/></bento>
    `,
  },
  {
    selectorName: "属性以选择器结尾",
    helpTitle:
      "Select all elements with an attribute value that ends with specific characters",
    doThis: "Select the items for names that end with 'ato'",
    selector: '[for$="ato"]',
    syntax: '[attribute$="value"]',
    help: "",
    examples: [
      '<strong>img[src$=".jpg"]</strong> selects all images display a <strong>.jpg</strong> image.',
    ],
    boardMarkup: `
    <apple class="small"/>
    <bento for="Hayato"><pickle/></bento>
    <apple for="Ryota"></apple>
    <plate for="Minato"><orange/></plate>
    <pickle class="small"/>
    `,
  },
  {
    selectorName: "属性通配符选择器",
    helpTitle:
      "Select all elements with an attribute value that contains specific characters anywhere",
    syntax: '[attribute*="value"]',
    doThis: "Select the meals for names that contain 'obb'",
    selector: '[for*="obb"]',
    help:
      "如果您可以在<strong> class </strong>，<strong> href </strong>或<strong> src </strong>属性之类的东西中识别出通用模式，则它是一个有用的选择器。",
    examples: [
      '<strong>img[src*="/thumbnails/"]</strong> selects all image elements that show images from the "thumbnails" folder.',
      '<strong>[class*="heading"]</strong> selects all elements with "heading" in their class, like <strong>class="main-heading"</strong> and <strong>class="sub-heading"</strong>',
    ],
    boardMarkup: `
    <bento for="Robbie"><apple /></bento>
    <bento for="Timmy"><pickle /></bento>
    <bento for="Bobby"><orange /></bento>
    `,
  },
];
