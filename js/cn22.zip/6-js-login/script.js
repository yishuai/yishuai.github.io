// 设置正确的用户名和密码
var correctUsername = "";
var correctPassword = "";


$("button").click(function() {
    var username = $(".username").val();
    var password = $(".password").val();
    
    //在下面加入代码



});