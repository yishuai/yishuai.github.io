import React, { Component } from "react";

class Number extends Component {
  render() {
    return <div>{this.props.号码}</div>;
  }
}

export default Number;
