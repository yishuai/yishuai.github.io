$("    ").click(function() {  
      
    
});

$("    ").click(function() {  
      
    
});

