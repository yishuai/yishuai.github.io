import { data } from "/data.js";

// Define a class containing the fields we want to use
// in our application.
class Person {
  constructor(data) {
    // 填写此构造函数
  }
}

function cleanDataSet() {
  let cleanData = [];
  for (let i = 0; i < data.length; i++) {
    // 清理我们的数据。丢弃任何东西
    // 不符合我们定义的模型。
  }

  return cleanData;
}
