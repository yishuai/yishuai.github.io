let guests = [];

$(".addButton").click(function() {
    let guest = $(".guestName").val();



});