请访问 https://popcode.org/?snapshot=d04583e4-555e-4084-a15d-a64d70adaac4，或下载 cn12.zip，完成下面的游戏

06.3 带参数的jQuery动作

1.编写jQuery代码，单击“Yes”按钮（replyYes）时，修改Homer的答复（homers-reply）。

2.单击“Yes”按钮（replyYes）时，使用.css（）操作，更改页面的CSS属性。

3.单击“No”按钮（replyNo）时，使用.css（）和.text（）操作，更改页面。

别忘了为点击（click）功能，写选择器。

4.单击“No”按钮（replyNo）时：
* 修改Homer的答复（homers-reply）为“ Doh！”
* 更改背景颜色
* 更改标题h1文本的颜色
* 放大Homer的图片

5.给“Yes”按钮添加更多的动作，比如
* 单击“Yes”时，将背景更改为甜甜圈照片。
* 单击“Yes”时，将Homer的照片更改为新图像。 _提示：您需要使用jQuery .attr（）_

请提交你网页的URL