class Animal {
  constructor(name, color, sound) {
    this.name = name;
    this.color = color;
    this.sound = sound;
  }
}

// 实例化Animal对象以反映
// 下面列出的每个动物。
// 例如：
const dog = new Animal("dog", "brown", "woof");
// const cow;
// const sheep;

console.log(dog);
// console.log(cow);
// console.log(sheep);

// 定义自己的Class来描述一项运动
class Sport {
  // 决定将使用哪些属性
  // 描述一项运动。
  constructor() {}
}

// 实例化以下运动对象。
// const volleyball;
// const soccer;
// const bowling;

// console.log(volleyball);
// console.log(soccer);
// console.log(bowling);
