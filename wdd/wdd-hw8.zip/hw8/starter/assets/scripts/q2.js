//
// Part 1: 修改函数 unhideLightbox. 后面，当单击图片时，我们将运行此函数。
//

/**
 * 使灯箱叠加层（lightbox overlay）可见，并显示与ID对应的灯箱弹出窗口
 *
 * @param {string} lightboxID 要显示的灯箱弹出窗口的ID
 */
function unhideLightbox(lightboxID) {
	// 从lightbox-overlay div中删除.hidden类
	document.getElementById('lightbox-overlay').classList.remove('hidden');

	// TODO: 从指定ID的div中删除.hidden类

}


//
// 第2部分：单击图片时运行unhideLightbox函数
//

/**
 * 用第一个灯箱的ID调用unhideLightbox
 */
function unhideLightbox1() {
	// TODO: 在q2.html中查找第一张图片的lightbox div的ID，然后调用unhideLightbox函数

}

// TODO: 将浏览器设置为在有人单击＃picture-1时运行unhideLightbox1函数


// TODO: 对＃picture-2执行相同的操作，编写一个函数，然后单击以使其运行





// TODO: 对＃picture-3执行相同的操作，编写一个函数，然后单击以使其运行






//
// 第3部分：现在，当我们在图片外面单击鼠标时，我们关闭灯箱！
//
function closeLightbox(lightboxID) {
	// 将.hidden类添加到＃lightbox-overlay div中
	document.getElementById('lightbox-overlay').classList.add('hidden');

	// TODO: 将.hidden类添加到具有给定ID的div中

}

// 关掉所有的灯箱。这个函数看不懂没关系
function closeAllLightboxes() {
	// 获取每个.lightbox div，getElementsByClassName给我们一个数组
	var lightboxElements = document.getElementsByClassName('lightbox');

	// 循环，遍历元素数组中的每个元素
	for (var i = 0; i < lightboxElements.length; i++) {
		// 获取此特定.lightbox div的ID
		var id = lightboxElements[i].id;
		// 为此ID调用closeLightbox
		closeLightbox(id);
	}
}

// TODO: 将closeAllLightboxes函数设置为在单击＃lightbox-overlay时运行
